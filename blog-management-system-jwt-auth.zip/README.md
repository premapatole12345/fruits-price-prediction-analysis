# Blog Management System — JWT Auth

Features: JWT login/register, bcrypt password hashing, protected API endpoints, per-user blog isolation (ownership enforced server-side), profile name update, logout, CRUD, search.

## Setup
1. Install Node.js and MongoDB.
2. Copy `.env.example` to `.env`; set a strong random `JWT_SECRET` and `MONGO_URI`.
3. In project directory: `npm install`
4. Run: `npm run dev`
5. Open Vite's displayed local URL (typically http://localhost:5173).

## Security notes
JWT currently is held in browser localStorage for a simple student/demo project. For production, prefer secure HttpOnly SameSite cookies, HTTPS, rate limiting, CORS allowlisting, input validation, and secret rotation. Never commit `.env`.
